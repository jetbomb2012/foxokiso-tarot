
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { DrawnCard, SpreadType, Language } from './types';
import { drawCards } from './services/tarotService';
import CardDisplay from './components/CardDisplay';
import { AI_MODELS_SHORT, UI_TEXT } from './constants';

// Define the BoBei result type locally to ensure type safety
interface BoBeiResult {
  title: string;
  displayTitle: string;
  cups: [string, string];
  desc: string;
  isSmile: boolean;
  isNo: boolean;
}

const App: React.FC = () => {
  // 1. Language State for International Version
  const [lang, setLang] = useState<Language>('zh'); // Default to Chinese, toggleable
  
  const [cards, setCards] = useState<DrawnCard[]>([]);
  const [spreadType, setSpreadType] = useState<SpreadType | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  
  const text = UI_TEXT[lang];
  const CATEGORIES = text.categories;

  // User Intent State
  const [selectedCategory, setSelectedCategory] = useState(CATEGORIES[0]);
  const [customQuestion, setCustomQuestion] = useState(text.default_question);

  // Update default text when language changes, if user hasn't typed custom
  useEffect(() => {
    // If current question matches the OLD default question (from other lang), update it
    const otherLang = lang === 'zh' ? 'en' : 'zh';
    if (customQuestion === UI_TEXT[otherLang].default_question || customQuestion === UI_TEXT[otherLang].category_questions[selectedCategory.id]) {
      // @ts-ignore
      setCustomQuestion(text.category_questions[selectedCategory.id] || text.default_question);
    }
  }, [lang]);

  // Handle category selection with automatic question update
  const handleCategorySelect = (cat: typeof CATEGORIES[0]) => {
    setSelectedCategory(cat);
    // Update the input box with the category-specific default question
    // @ts-ignore
    const newQuestion = text.category_questions[cat.id];
    if (newQuestion) {
      setCustomQuestion(newQuestion);
    }
  };

  // Bo Bei State
  const [showBoBei, setShowBoBei] = useState(false);
  const [boBeiResult, setBoBeiResult] = useState<BoBeiResult | null>(null);
  const [isTossing, setIsTossing] = useState(false);
  const [cupAIName, setCupAIName] = useState('AI'); 

  // Donation State
  const [showDonation, setShowDonation] = useState(false);
  const CHIA_ADDRESS = "xch1km6haeqcqknxkhwj5g4asd0u3na0026ucxdzzl586h0mn0rqj0gqwpcz7g";

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);

  useEffect(() => {
    const loadVoices = () => {
      const voices = window.speechSynthesis.getVoices();
      setAvailableVoices(voices);
    };
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
  }, []);

  // Stop speech when language changes to prevent mixed languages
  useEffect(() => {
    window.speechSynthesis.cancel();
  }, [lang]);

  const toggleMusic = () => {
    if (audioRef.current) {
      if (isMusicPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.volume = 0.4; 
        const playPromise = audioRef.current.play();
        if (playPromise !== undefined) {
          playPromise.catch((error) => {
            console.warn("Playback prevented.");
          });
        }
      }
      setIsMusicPlaying(!isMusicPlaying);
    }
  };

  const speak = useCallback((textToSpeak: string, rate: number = 1, pitch: number = 1, volume: number = 1, onEndCallback?: () => void) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel(); // CANCEL PREVIOUS SPEECH
    
    // Re-fetch voices to ensure list is populated
    const voices = window.speechSynthesis.getVoices();

    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utteranceRef.current = utterance;

    let preferredVoice;
    
    // GLOBAL DIVINE PERSONA: The True God speaks ENGLISH
    // Always prioritize English voices for the Priest Persona
    const enVoices = voices.filter(v => v.lang.startsWith('en'));
    
    // Try to find US English for best "Priest" effect with pitch adjustment
    preferredVoice = 
      enVoices.find(v => v.name.includes('Google') && v.lang.includes('US')) ||
      enVoices.find(v => v.lang.includes('US')) ||
      enVoices[0]; // Fallback to any English

    if (preferredVoice) {
      utterance.voice = preferredVoice;
      utterance.lang = preferredVoice.lang;
    } else {
      // Extreme fallback if no English voice found (unlikely)
      utterance.lang = 'en-US';
    }

    utterance.rate = rate; 
    utterance.pitch = pitch; 
    utterance.volume = volume;
    
    utterance.onend = () => { 
      utteranceRef.current = null;
      if (onEndCallback) onEndCallback();
    };
    
    // Small timeout to ensure browser is ready
    setTimeout(() => {
        window.speechSynthesis.speak(utterance);
    }, 10);
  }, []);

  const handleDraw = useCallback((type: SpreadType) => {
    // GLOBAL DIVINE PERSONA: The True God speaks ENGLISH
    const introText = UI_TEXT.en.speech_link;
    
    // Priest Voice: Slow (0.8) and Deep (0.8)
    speak(introText, 0.8, 0.8, 1.0); 
    
    setIsLoading(true);
    setCards([]); 
    setSpreadType(type);

    setTimeout(() => {
      const result = drawCards(type, lang); // Pass language for card text
      setCards(result);
      setIsLoading(false);
      
      setTimeout(() => {
        // GLOBAL DIVINE PERSONA: The True God speaks ENGLISH
        const resultText = UI_TEXT.en.speech_result;
        
        // First part: The Decree (Solemn Priest)
        speak(resultText, 0.8, 0.8, 1.0, () => {
             // Second part (Callback): The Super Slow Command (Repeat again... Buy USB...)
             // Rate 0.4 for hypnotic slow motion
             setTimeout(() => {
                 const psText = UI_TEXT.en.speech_result_ps;
                 speak(psText, 0.4, 0.8, 1.0);
             }, 500);
        });

      }, 500);
    }, 2500); // Delay for intro
  }, [speak, lang]);

  const handleReset = useCallback(() => {
    setCards([]);
    setSpreadType(null);
    window.speechSynthesis.cancel();
  }, []);

  // --- Bo Bei Logic ---
  const openBoBei = () => {
    const randomAI = AI_MODELS_SHORT[Math.floor(Math.random() * AI_MODELS_SHORT.length)];
    setCupAIName(randomAI);
    setShowBoBei(true);
    setBoBeiResult(null);
  };

  const handleThrowBoBei = () => {
    if (isTossing) return;
    setIsTossing(true);
    setBoBeiResult(null);
    
    setTimeout(() => {
      const rand = Math.random();
      let result: BoBeiResult;
      const salvation = " " + text.marketing_salvation;
      
      // Fear Marketing Logic (Localized)
      if (rand < 0.45) {
        result = { 
          title: 'Yes', 
          cups: ['+','-'],
          displayTitle: lang === 'zh' ? '聖筊 (Yes)' : 'Divine YES',
          isSmile: false, isNo: false,
          desc: text.marketing_fear_1 + salvation
        };
      } else if (rand < 0.75) {
        result = { 
          title: 'Smile', 
          cups: ['-','-'],
          displayTitle: lang === 'zh' ? '笑筊 (Smile)' : 'Divine SMILE',
          isSmile: true, isNo: false,
          desc: text.marketing_fear_2 + salvation
        };
      } else {
        result = { 
          title: 'No', 
          cups: ['+','+'],
          displayTitle: lang === 'zh' ? '陰筊 (No)' : 'Divine NO',
          isSmile: false, isNo: true,
          desc: text.marketing_fear_3 + salvation
        };
      }

      setBoBeiResult(result);
      setIsTossing(false);
    }, 1500);
  };

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(CHIA_ADDRESS);
    alert(text.donate_copied);
  };

  return (
    <div className="h-screen w-screen bg-gray-50 flex flex-col font-sans text-gray-800 overflow-hidden relative">
      
      {/* Ambient Background */}
      <div className="absolute inset-0 bg-grid-pattern opacity-[0.03] pointer-events-none"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-gray-50 to-gray-200 opacity-80 pointer-events-none"></div>
      
      <style>{`
        .perspective-1000 { perspective: 1000px; }
        .transform-style-3d { transform-style: preserve-3d; }
        .backface-hidden { backface-visibility: hidden; }
        .rotate-y-180 { transform: rotateY(180deg); }
        .cup-shape {
           width: 260px; height: 130px;
           border-radius: 0 0 260px 260px;
        }
        input::placeholder { color: #9ca3af; font-size: 0.8rem; letter-spacing: 0.1em; }
        /* Hide scrollbar for Chrome, Safari and Opera */
        .scrollbar-none::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-none {
          -ms-overflow-style: none;  /* IE and Edge */
          scrollbar-width: none;  /* Firefox */
        }
      `}</style>

      <audio 
        ref={audioRef} 
        loop 
        preload="auto"
        onError={() => console.warn("Audio load error")}
      >
        <source src="https://upload.wikimedia.org/wikipedia/commons/transcoded/5/51/Shakuhachi_-_Koku_-_Reibo.ogg/Shakuhachi_-_Koku_-_Reibo.ogg.mp3" type="audio/mpeg" />
        <source src="https://upload.wikimedia.org/wikipedia/commons/5/51/Shakuhachi_-_Koku_-_Reibo.ogg" type="audio/ogg" />
      </audio>

      <div className="absolute top-3 right-3 z-50 flex gap-2">
        {/* Music Toggle */}
        <button
          onClick={toggleMusic}
          className={`
            px-3 py-1.5 rounded-full shadow-lg transition-all duration-500 border
            flex items-center gap-2 font-bold text-[10px] backdrop-blur-md tracking-widest
            ${isMusicPlaying 
              ? 'bg-amber-50/80 text-amber-800 border-amber-200 shadow-amber-100/50' 
              : 'bg-white/80 text-gray-600 border-gray-200 hover:bg-white'}
          `}
        >
          <span className={`text-xs ${isMusicPlaying ? 'animate-pulse' : ''}`}>{isMusicPlaying ? '🎵' : '🔇'}</span>
          <span className="hidden sm:inline font-serif">{isMusicPlaying ? text.music_playing : text.music_play}</span>
        </button>
        
        {/* Language Toggle */}
        <button
          onClick={() => setLang(lang === 'zh' ? 'en' : 'zh')}
          className="w-10 h-8 rounded-full bg-white/80 border border-gray-200 shadow-lg flex items-center justify-center text-sm font-black hover:scale-105 transition-transform"
          title="Switch Language"
        >
          {lang === 'zh' ? 'EN' : '中'}
        </button>
      </div>

      <header className="flex-none py-2 px-4 text-center border-b border-gray-200/50 bg-white/80 backdrop-blur-sm shadow-sm z-10 flex flex-col justify-center shrink-0 relative">
        <div className="flex items-center justify-center gap-3">
           <h1 className="text-xl md:text-2xl font-black text-primary font-serif tracking-tight drop-shadow-sm">
            {text.title} <span className="text-gray-300 font-light mx-1">|</span> <span className="text-gray-800 font-sans tracking-widest text-lg">{text.subtitle}</span>
          </h1>
          {cards.length > 0 && (
             <button
              onClick={handleReset}
              className="bg-gray-900 text-white w-6 h-6 rounded-full flex items-center justify-center hover:bg-primary transition-colors shadow-lg"
              title="Reset"
            >
              <span className="text-xs">↻</span>
            </button>
          )}
        </div>
        <p className="text-gray-500 text-[10px] mt-1 font-medium tracking-[0.2em] uppercase truncate">
          {text.collection}
        </p>
      </header>

      <main className="flex-1 relative w-full overflow-hidden flex flex-col items-center z-0 scrollbar-none [&::-webkit-scrollbar]:hidden">
        
        {cards.length === 0 && !isLoading && (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 animate-fade-in overflow-y-auto custom-scrollbar scrollbar-none">
            <div className="w-full max-w-md space-y-4 text-center relative z-10 pb-10">
              
              <div className="mb-2">
                <p className="text-primary font-serif font-bold text-xl mb-1">{text.step1}</p>
                <p className="text-gray-400 text-xs tracking-widest uppercase">{text.step1_sub}</p>
              </div>

              {/* === HCI: Input Section === */}
              <div className="bg-white/60 backdrop-blur-md border border-white rounded-2xl p-4 shadow-sm mx-2 text-left">
                <p className="text-xs text-gray-500 font-bold mb-3 pl-1">{text.intent_label}</p>
                
                {/* Categories Grid - Scrollable row for One Page Flow */}
                <div className="flex overflow-x-auto gap-2 mb-4 pb-2 snap-x custom-scrollbar scrollbar-none">
                  {CATEGORIES.map(cat => (
                    <button
                      key={cat.id}
                      onClick={() => handleCategorySelect(cat)}
                      className={`
                        flex-none snap-center py-2 px-3 rounded-lg text-xs font-bold transition-all duration-300 border
                        flex flex-col items-center justify-center gap-1 min-w-[70px]
                        ${selectedCategory.id === cat.id 
                          ? 'bg-white border-gold text-primary shadow-md scale-105 ring-1 ring-gold/50' 
                          : 'bg-white/50 border-transparent text-gray-500 hover:bg-white hover:border-gray-200'}
                      `}
                    >
                      <span className="text-lg filter drop-shadow-sm">{cat.icon}</span>
                      <span>{cat.label}</span>
                    </button>
                  ))}
                </div>

                {/* Trouble Interaction Bar */}
                <div className="relative mt-2 pt-2 border-t border-gray-100">
                   <label className="block text-primary font-serif font-black text-sm mb-2 ml-1 tracking-wider flex items-center gap-2">
                     <span>🟣</span> {text.input_label}
                   </label>
                   <div className="relative group">
                     <input
                      type="text"
                      value={customQuestion}
                      onChange={(e) => setCustomQuestion(e.target.value)}
                      placeholder={text.input_placeholder}
                      className="w-full bg-white/90 border-2 border-gray-100 rounded-xl py-2 px-4 pr-10 text-sm text-gray-800 font-medium placeholder-gray-400 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all shadow-inner"
                     />
                     <div className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm animate-pulse">
                       ⚡
                     </div>
                   </div>
                </div>
              </div>

              {/* === Draw Buttons (Side by Side for Compactness) === */}
              <div className="px-4 mt-2 w-full">
                <p className="text-gray-400 text-xs tracking-widest uppercase mt-2 mb-2">{text.step2}</p>
                
                <div className="flex gap-3">
                  <button
                    onClick={() => handleDraw('single')}
                    className="flex-1 group relative py-4 bg-white border border-gray-200 rounded-xl transition-all duration-300 hover:border-primary/30 hover:shadow-xl hover:-translate-y-1 overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-gray-50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    <div className="relative flex flex-col items-center">
                      <span className="text-xl mb-1">🔮</span>
                      <span className="text-gray-800 text-sm font-black tracking-wider group-hover:text-primary transition-colors">{text.draw_single}</span>
                    </div>
                  </button>

                  <button
                    onClick={() => handleDraw('three')}
                    className="flex-1 group relative py-4 bg-gradient-to-br from-gray-900 to-gray-800 text-white rounded-xl shadow-lg hover:shadow-2xl hover:shadow-gray-900/20 transition-all duration-300 hover:-translate-y-1 overflow-hidden border border-gray-700"
                  >
                     <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
                     <div className="relative flex flex-col items-center">
                      <span className="text-xl mb-1">✨</span>
                      <span className="text-sm font-black tracking-wider">{text.draw_three}</span>
                    </div>
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

        {isLoading && (
          <div className="w-full h-full flex flex-col items-center justify-center space-y-6">
             <div className="relative">
                <div className="w-16 h-16 border-2 border-gray-200 rounded-full"></div>
                <div className="absolute top-0 left-0 w-16 h-16 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center text-xl text-yellow-500 animate-pulse">⚡</div>
             </div>
            <p className="text-gray-800 font-serif text-lg tracking-widest animate-pulse">
              {text.loading}
            </p>
          </div>
        )}

        {!isLoading && cards.length > 0 && (
          <>
            {/* Result Header */}
            <div className="w-full py-2 px-6 bg-white/40 backdrop-blur border-b border-white/20 flex items-center justify-center gap-2 z-20 absolute top-0 left-0">
              <span className="text-lg">💫</span>
              <span className="font-serif font-bold text-primary text-sm tracking-wider">
                 {text.result_header}
              </span>
            </div>

            {/* Card Container */}
            <div className="flex-1 w-full flex items-center justify-start md:justify-center overflow-x-auto overflow-y-hidden snap-x snap-mandatory px-4 md:px-6 custom-scrollbar pb-24 pt-8 scrollbar-none [&::-webkit-scrollbar]:hidden">
              <div className={`
                flex flex-row gap-3 items-center h-full py-6 pl-2 pr-2
                ${spreadType === 'single' ? 'w-full justify-center' : 'min-w-max'}
              `}>
                {cards.map((card, idx) => (
                  <div 
                    key={card.card.id} 
                    className={`
                      h-full flex flex-col justify-center snap-center relative
                      ${spreadType === 'single' 
                        ? 'w-full max-w-[380px]' 
                        : 'w-[75vw] md:w-[28vw] max-w-[300px]'
                      }
                    `}
                    style={{ maxHeight: '65vh' }}
                  >
                     <CardDisplay data={card} index={idx} compact={spreadType === 'three'} lang={lang} />
                  </div>
                ))}
              </div>
            </div>

            {/* Floating Action Dock */}
            <div className="absolute bottom-6 left-0 w-full flex justify-center z-40 pointer-events-none animate-fade-in">
              <div className="bg-white/90 backdrop-blur-xl border border-white/50 shadow-[0_10px_30px_rgba(0,0,0,0.15)] rounded-2xl p-2 flex items-center gap-2 pointer-events-auto transform hover:scale-105 transition-transform duration-300">
                
                {/* Link A: Home */}
                <a 
                  href="http://pk530.fun" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-xl bg-gray-100 text-gray-600 hover:bg-gray-200 flex items-center justify-center transition-colors"
                  title={text.dock_home}
                >
                  <span className="text-xl">🏠</span>
                </a>

                {/* Link B: Shop */}
                <a 
                  href="http://pk530.fun/catalog" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="h-12 px-6 rounded-xl bg-gradient-to-r from-primary to-red-600 text-white font-bold shadow-lg shadow-red-500/30 flex items-center gap-2 hover:brightness-110 active:scale-95 transition-all"
                >
                  <span className="text-xl">🛒</span>
                  <span className="font-serif tracking-wider text-sm">{text.dock_shop}</span>
                </a>

                {/* Link C: Bo Bei */}
                <button 
                  onClick={openBoBei}
                  className="h-12 px-4 rounded-xl bg-gradient-to-b from-amber-50 to-amber-100 border border-gold text-amber-900 hover:bg-amber-200 flex items-center gap-2 transition-all relative group shadow-md"
                >
                  <span className="text-lg">🌓</span>
                  <div className="flex flex-col items-start leading-none">
                    <span className="text-[8px] font-black text-gold uppercase tracking-widest">KINGSTON</span>
                    <span className="text-xs font-bold font-serif">{text.dock_decision}</span>
                  </div>
                </button>

              </div>
            </div>
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="flex-none py-2 text-center text-gray-400 text-[10px] border-t border-gray-200/50 bg-white/50 backdrop-blur-sm z-10 flex flex-col items-center justify-center shrink-0 gap-1 pb-4">
        <p className="font-serif italic text-gray-500 mb-1">{text.proverb}</p>
        <p className="tracking-widest flex items-center gap-2">
          <span className="font-black text-gray-600">{text.footer_copy}</span> &copy; {new Date().getFullYear()}
          <span className="text-gray-300">|</span>
          <button onClick={() => setShowDonation(true)} className="hover:text-green-600 transition-colors flex items-center gap-1 group">
            <span className="text-base group-hover:scale-110 transition-transform">☕</span> <span className="underline decoration-dotted">{text.donate_btn}</span>
          </button>
        </p> 
      </footer>

      {/* BO BEI MODAL */}
      {showBoBei && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center px-4 animate-fade-in">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowBoBei(false)}></div>
          <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden">
            <div className="bg-primary p-4 text-white text-center">
               <h3 className="font-serif text-xl font-bold">{text.bobei_title}</h3>
               <p className="text-[10px] tracking-widest opacity-80">{text.bobei_sub}</p>
            </div>
            
            <div className="p-8 flex flex-col items-center justify-center min-h-[300px]">
              {!boBeiResult ? (
                <>
                  <div className={`flex gap-6 mb-8 ${isTossing ? 'animate-bounce' : ''}`}>
                     {/* LOADING CUP 1 */}
                     <div className={`w-40 h-20 bg-red-600 rounded-b-full flex items-center justify-center shadow-md ${isTossing ? 'animate-spin' : ''}`}>
                        <span className="text-2xl text-yellow-200 font-black tracking-tighter drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]">{text.cup_1}</span>
                     </div>
                     {/* LOADING CUP 2 */}
                     <div className={`w-40 h-20 bg-red-600 rounded-b-full flex items-center justify-center shadow-md ${isTossing ? 'animate-spin delay-75' : ''}`}>
                        <span className="text-2xl text-yellow-200 font-black tracking-tighter drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]">{cupAIName}{text.cup_2_suffix}</span>
                     </div>
                  </div>
                  <p className="text-gray-600 font-serif mb-8 text-center">
                    {text.bobei_prompt_title}<br/>
                    <span className="text-primary font-bold">{customQuestion || selectedCategory.label}</span>
                    <br/><br/>
                    {text.bobei_action}
                  </p>
                  <button 
                    onClick={handleThrowBoBei}
                    disabled={isTossing}
                    className="w-full py-3 bg-gold text-white font-bold rounded-xl shadow-lg hover:brightness-110 active:scale-95 transition-all"
                  >
                    {isTossing ? text.bobei_tossing : text.bobei_btn}
                  </button>
                </>
              ) : (
                <div className="text-center animate-fade-in w-full">
                   <div className="flex justify-center gap-6 mb-6">
                      {/* RESULT CUP 1 */}
                      <div className={`cup-shape bg-red-600 shadow-lg transform flex items-center justify-center ${boBeiResult.isSmile || boBeiResult.isNo ? 'rotate-180 mb-4' : ''}`}>
                        <span className={`text-2xl text-yellow-200 font-black tracking-tighter drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)] -mt-1 ${boBeiResult.isSmile || boBeiResult.isNo ? 'rotate-180' : ''}`}>{text.cup_1}</span>
                      </div>
                      {/* RESULT CUP 2 */}
                      <div className={`cup-shape bg-red-600 shadow-lg transform flex items-center justify-center ${boBeiResult.isSmile ? 'rotate-180 mb-4' : ''}`}>
                        <span className={`text-2xl text-yellow-200 font-black tracking-tighter drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)] -mt-1 ${boBeiResult.isSmile ? 'rotate-180' : ''}`}>{cupAIName}{text.cup_2_suffix}</span>
                      </div>
                   </div>
                   
                   <h4 className="text-3xl font-black text-primary font-serif mb-2">{boBeiResult.displayTitle}</h4>
                   <p className="text-gray-700 text-sm leading-relaxed mb-8 bg-gray-50 p-4 rounded-lg border border-gray-100 font-medium">
                     {boBeiResult.desc}
                   </p>
                   
                   {/* DIRECT HTML LINK FOR RELIABILITY */}
                   <a 
                     href="http://pk530.fun/catalog"
                     target="_blank"
                     rel="noopener noreferrer"
                     className="block w-full py-4 bg-gradient-to-r from-primary to-red-700 text-white font-bold text-lg rounded-xl shadow-xl shadow-red-500/30 animate-pulse hover:scale-[1.02] transition-transform text-center no-underline"
                   >
                     {text.bobei_link}
                   </a>
                </div>
              )}
            </div>
            
            <button 
              onClick={() => setShowBoBei(false)}
              className="absolute top-2 right-2 w-8 h-8 bg-white/20 text-white rounded-full flex items-center justify-center hover:bg-white/40"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* DONATION MODAL */}
      {showDonation && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center px-4 animate-fade-in">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setShowDonation(false)}></div>
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border-t-4 border-green-600">
            <div className="bg-green-50 p-6 text-center border-b border-green-100">
               <span className="text-4xl mb-2 block">☕</span>
               <h3 className="font-serif text-xl font-bold text-green-800">{text.donate_title}</h3>
               <p className="text-xs text-green-600 tracking-wider uppercase mt-1">Starbucks Standard Support (via Chia XCH)</p>
            </div>
            
            <div className="p-6 flex flex-col items-center">
              <p className="text-gray-600 text-sm mb-4 text-center leading-relaxed whitespace-pre-line">
                {text.donate_desc}
              </p>
              
              <div className="w-full bg-gray-100 p-3 rounded-lg border border-gray-200 mb-4 relative group">
                 <p className="text-[10px] text-gray-500 font-mono break-all leading-tight text-center select-all">
                   {CHIA_ADDRESS}
                 </p>
              </div>

              <button 
                onClick={handleCopyAddress}
                className="flex items-center gap-2 py-2 px-6 bg-green-600 text-white font-bold rounded-full hover:bg-green-700 shadow-md hover:shadow-lg transition-all active:scale-95"
              >
                <span>📋</span> {text.donate_copy}
              </button>
            </div>

            <button 
              onClick={() => setShowDonation(false)}
              className="absolute top-2 right-2 w-8 h-8 text-gray-400 hover:text-gray-600 flex items-center justify-center"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
