
export type Language = 'zh' | 'en';

export interface CardData {
  id: number;
  name: string;
  roman: string;
  meaningUpright: string;
  meaningReversed: string;
}

export interface DrawnCard {
  card: CardData;
  isReversed: boolean;
  positionLabel?: string; // e.g., "Past", "Present", "Future"
  recommendedOS: string; // Random OS recommendation
  aiPhrase: string; // New field for the AI love phrase
}

export type SpreadType = 'single' | 'three';
