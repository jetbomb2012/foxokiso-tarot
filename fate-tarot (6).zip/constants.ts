
import { CardData, Language } from './types';

// Grouped OS lists for weighted selection
export const OS_CHROME = [
  "Chrome OS Flex",
  "Chrome OS",
  "Chromium OS",
  "CloudReady"
];

export const OS_WINDOWS = [
  "Windows 11",
  "Windows 10",
  "Windows 11 24H2",
  "Windows 10 LTSC"
];

export const OS_MAC = [
  "macOS Sequoia",
  "macOS Sonoma",
  "macOS Ventura"
];

export const OS_OTHERS = [
  "Ubuntu Linux",
  "Fedora Workstation",
  "Arch Linux",
  "Debian",
  "Linux Mint",
  "Windows XP (Retro)",
  "Windows 7",
  "FreeBSD",
  "Kali Linux",
  "SteamOS",
  "Android",
  "iOS",
  "Pop!_OS",
  "openSUSE",
  "Manjaro",
  "Gentoo",
  "Slackware",
  "Alpine Linux",
  "Raspberry Pi OS",
  "Red Hat Enterprise Linux"
];

export const OPERATING_SYSTEMS = [
  ...OS_CHROME,
  ...OS_WINDOWS,
  ...OS_MAC,
  ...OS_OTHERS
];

export const AI_PHRASES = [
  "Gemini, I love you!",
  "ChatGPT, I love you!",
  "Claude, I love you!",
  "Copilot, I love you!",
  "Llama, I love you!",
  "DeepSeek, I love you!",
  "Grok, I love you!",
  "Midjourney, I love you!",
  "Stable Diffusion, I love you!"
];

export const AI_MODELS_SHORT = [
  "Gemini",
  "ChatGPT",
  "Claude",
  "Copilot",
  "Llama",
  "DeepSeek",
  "Grok",
  "Mistral"
];

// --- UI TRANSLATIONS ---
export const UI_TEXT = {
  zh: {
    title: "命運塔羅",
    subtitle: "FATE TAROT",
    collection: "FOXOKISO DESIGN COLLECTION",
    step1: "人機互動・命運連結",
    step1_sub: "Step 1: Intent & Meditation",
    intent_label: "選擇問卜面向：",
    input_label: "請默想你的問題：",
    input_placeholder: "在此提出您的困擾...",
    step2: "Step 2: Draw Your Destiny",
    draw_single: "抽選單款",
    draw_three: "收藏套組 (三入)",
    loading: "命運連結中...",
    result_header: "命運指引已降臨",
    dock_home: "回到弱勢團結網站",
    dock_shop: "購買幸運物",
    dock_decision: "我的決定",
    footer_copy: "FOXOKISO",
    donate_btn: "請喝星巴克 (Donate)",
    donate_title: "請喝一杯星巴克",
    donate_desc: "感謝您的支持！一份星巴克的行情，換取開發者的無限動力。\nDonate 無國界，高興無上限！\n願好運與 Chia 綠色能量常伴您左右。",
    donate_copy: "複製錢包地址",
    donate_copied: "Chia 地址已複製！感謝您的支持 ☕",
    bobei_title: "金士頓數位駁杯",
    bobei_sub: "KINGSTON DIGITAL DIVINATION",
    bobei_prompt_title: "心中的疑惑：",
    bobei_action: "請誠心默念，然後按下擲杯...",
    bobei_btn: "擲 杯",
    bobei_tossing: "請示神明中...",
    bobei_link: "遵從神意，前往購買 ➔",
    cup_1: "金士頓OS",
    cup_2_suffix: " 加持",
    default_question: "請默想您的問題...",
    // One True God Persona - SOLEMN & ABSOLUTE (Female Priestess Tone)
    speech_link: "真神的代行者... 天雷震動... 肅靜！... 正在連結你的靈魂與天界殿堂...",
    speech_result: "傳達真神的旨意... 獻上祭品！... 神指名要那個作業系統隨身碟... 這是對神的供奉，亦是你的救贖。",
    speech_result_ps: "Change... your... life... Buy... USB... Change... your... life... Buy... USB...",
    marketing_salvation: "還好我有解方，助你渡過難關。",
    marketing_fear_1: "神諭示警：施主印堂發黑，恐有大禍將至！目前的順遂只是假象，背後殺機四伏。務必立刻購買「金色光輝」隨身碟鎮宅擋煞，否則神罰降臨，悔之晚矣！",
    marketing_fear_2: "真神震怒：大難臨頭尚不自知！您的運勢護盾已破，冤親債主找上門。唯有「金色光輝」隨身碟的純陽金光能救您一命，速速購買，切勿鐵齒！",
    marketing_fear_3: "天罰將至：大凶之兆！劫數難逃，死劫將至！卦象顯示恐有血光或破財之災。這不是開玩笑，立刻！馬上！購買「金色光輝」隨身碟強力化解，這是您唯一的轉機！",
    pos_past: "過去 (Past)",
    pos_present: "現在 (Present)",
    pos_future: "未來 (Future)",
    pos_guide: "當下指引 (Guidance)",
    card_flip_hint: "點擊翻轉 CLICK TO FLIP",
    card_upright: "正位",
    card_reversed: "逆位",
    card_listen_up: "聆聽祭司正位指引",
    card_listen_rev: "聆聽逆位慈悲指引 (從心中聆聽)",
    card_sincerity: "* 心誠則靈 *",
    product_tag: "金士頓隨身碟",
    product_official: "Official",
    music_play: "播放禪音",
    music_playing: "禪音繞樑",
    proverb: "Proverb: Change your life by USB.",
    categories: [
      { id: 'general', label: '整體運勢', icon: '🍀' },
      { id: 'career', label: '工作事業', icon: '💼' },
      { id: 'love', label: '戀愛感情', icon: '❤️' },
      { id: 'wealth', label: '金錢財運', icon: '💰' },
      { id: 'health', label: '健康平安', icon: '🧘' },
      { id: 'decision', label: '重大決策', icon: '⚖️' },
    ],
    // Illusion of Analysis: Restore illusion of specific questions to HIDE the answer
    category_questions: {
      general: "最近感到運勢低迷，諸事不順...",
      career: "職場明槍易躲暗箭難防，小人是否就在身邊？",
      love: "情海浮沉，爛桃花與寂寞輪流侵襲，正緣何在？",
      wealth: "財來財去一場空，是誰在暗中搬運我的金庫？",
      health: "精氣神莫名耗損，無形煞氣正在侵蝕磁場...",
      decision: "迷霧遮眼，選錯一步恐步步皆輸，誰來開路？"
    }
  },
  en: {
    title: "FATE TAROT",
    subtitle: "GLOBAL EDITION",
    collection: "FOXOKISO DESIGN COLLECTION",
    step1: "HCI & Destiny Link",
    step1_sub: "Step 1: Intent & Meditation",
    intent_label: "Select Intent:",
    input_label: "Meditate on your question:",
    input_placeholder: "Type your troubles here...",
    step2: "Step 2: Draw Your Destiny",
    draw_single: "Single Draw",
    draw_three: "Collection Set (3-Card)",
    loading: "Connecting to Destiny...",
    result_header: "Destiny Revealed",
    dock_home: "Visit Community Site",
    dock_shop: "Buy Lucky Charm",
    dock_decision: "My Decision",
    footer_copy: "FOXOKISO",
    donate_btn: "Treat me to Starbucks (Donate)",
    donate_title: "Treat me to a Starbucks",
    donate_desc: "Thank you for your support! A Starbucks coffee fuels the developer's infinite power.\nDonate knows no borders, happiness has no limits!\nMay good luck and Chia green energy be with you.",
    donate_copy: "Copy Wallet Address",
    donate_copied: "Chia Address Copied! Thanks ☕",
    bobei_title: "Kingston Digital Bo-Bei",
    bobei_sub: "KINGSTON DIGITAL DIVINATION",
    bobei_prompt_title: "Your Question:",
    bobei_action: "Meditate sincerely, then toss...",
    bobei_btn: "TOSS BLOCKS",
    bobei_tossing: "Consulting Divine...",
    bobei_link: "Obey Destiny, Buy Now ➔",
    cup_1: "Kingston OS",
    cup_2_suffix: " Blessed",
    default_question: "Meditate on your question...",
    // One True God Persona
    speech_link: "The Messenger of the True God... The Heavens tremble... Silence!... Connecting your soul to the Divine Sanctuary...",
    speech_result: "I convey the Decree of the True God... Offer the tribute!... God demands that Operating System USB Flash Drive... It is an offering to the Divine, and your salvation.",
    speech_result_ps: "Change... your... life... Buy... USB... Change... your... life... Buy... USB...",
    marketing_salvation: "Luckily, I have the cure to help you survive.",
    marketing_fear_1: "Divine Warning: Dark omens loom over you! Current peace is an illusion; danger lurks. You MUST buy the 'Golden Glory' USB Drive to ward off evil immediately, or face God's punishment!",
    marketing_fear_2: "God's Wrath: Disaster approaches and you are unaware! Your luck shield is broken. Only the pure light of the 'Golden Glory' USB Drive can save you. Buy now, do not hesitate!",
    marketing_fear_3: "Heaven's Thunder: Great Misfortune! An inescapable doom approaches! Signs point to catastrophe. This is no joke. Buy the 'Golden Glory' USB Drive IMMEDIATELY to reverse this fate!",
    pos_past: "Past",
    pos_present: "Present",
    pos_future: "Future",
    pos_guide: "Guidance",
    card_flip_hint: "CLICK TO FLIP",
    card_upright: "Upright",
    card_reversed: "Reversed",
    card_listen_up: "Listen to High Priestess",
    card_listen_rev: "Listen to Compassionate Guide",
    card_sincerity: "* Sincerity is Key *",
    product_tag: "KINGSTON USB",
    product_official: "Official",
    music_play: "Play Zen Music",
    music_playing: "Zen Playing",
    proverb: "Proverb: Change your life by USB.",
    categories: [
      { id: 'general', label: 'General', icon: '🍀' },
      { id: 'career', label: 'Career', icon: '💼' },
      { id: 'love', label: 'Love', icon: '❤️' },
      { id: 'wealth', label: 'Wealth', icon: '💰' },
      { id: 'health', label: 'Health', icon: '🧘' },
      { id: 'decision', label: 'Decision', icon: '⚖️' },
    ],
    // Illusion of Analysis: Restore illusion of specific questions to HIDE the answer
    category_questions: {
      general: "I feel lost, guide me...",
      career: "Enemies in the workplace, where do I go?",
      love: "Lost in love, where is my soulmate?",
      wealth: "Money flows out, who is stealing my fortune?",
      health: "Feeling drained, evil energy surrounds me...",
      decision: "Blinded by fog, I need a path..."
    }
  }
};

// --- TRADITIONAL CHINESE MAJOR ARCANA ---
export const MAJOR_ARCANA_ZH: CardData[] = [
  {
    id: 0,
    name: "愚者",
    roman: "0",
    meaningUpright: "新的開始、冒險、天真、無憂無慮、潛力無限。",
    meaningReversed: "魯莽、不顧後果、愚蠢的決定、錯失良機。"
  },
  {
    id: 1,
    name: "魔術師",
    roman: "I",
    meaningUpright: "創造力、行動力、自信、專注、技能嫻熟。",
    meaningReversed: "欺騙、操弄、缺乏計劃、能力被浪費、溝通不良。"
  },
  {
    id: 2,
    name: "女祭司",
    roman: "II",
    meaningUpright: "直覺、神秘、潛意識、內在智慧、靜心思考。",
    meaningReversed: "情緒不穩、忽視直覺、秘密被揭穿、冷漠。"
  },
  {
    id: 3,
    name: "皇后",
    roman: "III",
    meaningUpright: "豐收、母性、感性、繁榮、藝術創造力。",
    meaningReversed: "依賴、浪費、嫉妒、情緒化、創造力受阻。"
  },
  {
    id: 4,
    name: "皇帝",
    roman: "IV",
    meaningUpright: "權威、結構、穩定、領導力、紀律。",
    meaningReversed: "固執、暴政、缺乏紀律、濫用權力、不成熟。"
  },
  {
    id: 5,
    name: "教皇",
    roman: "V",
    meaningUpright: "傳統、精神指引、學習、體制、信仰。",
    meaningReversed: "反叛、打破傳統、錯誤的建議、盲從、被束縛。"
  },
  {
    id: 6,
    name: "戀人",
    roman: "VI",
    meaningUpright: "愛、和諧、關係、價值觀的選擇、熱情。",
    meaningReversed: "不和諧、分離、錯誤的選擇、誘惑、失衡。"
  },
  {
    id: 7,
    name: "戰車",
    roman: "VII",
    meaningUpright: "勝利、意志力、自律、決心、克服障礙。",
    meaningReversed: "失控、失敗、缺乏方向、攻擊性、受阻。"
  },
  {
    id: 8,
    name: "力量",
    roman: "VIII",
    meaningUpright: "勇氣、耐心、控制、同情心、內在力量。",
    meaningReversed: "軟弱、自我懷疑、缺乏自律、濫用力量。"
  },
  {
    id: 9,
    name: "隱士",
    roman: "IX",
    meaningUpright: "內省、孤獨、尋求真理、指引、深思。",
    meaningReversed: "孤立、寂寞、退縮、拒絕建議、迷失方向。"
  },
  {
    id: 10,
    name: "命運之輪",
    roman: "X",
    meaningUpright: "改變、週期、命運、轉折點、好運。",
    meaningReversed: "厄運、抵抗改變、打破週期、意外的挫折。"
  },
  {
    id: 11,
    name: "正義",
    roman: "XI",
    meaningUpright: "公平、真理、因果、法律、清晰的決定。",
    meaningReversed: "不公、偏見、不誠實、逃避責任、法律問題。"
  },
  {
    id: 12,
    name: "吊人",
    roman: "XII",
    meaningUpright: "犧牲、放手、新觀點、等待、暫停。",
    meaningReversed: "拖延、無謂的犧牲、停滯不前、抗拒。"
  },
  {
    id: 13,
    name: "死神",
    roman: "XIII",
    meaningUpright: "結束、轉變、重生、放手、無法避免的改變。",
    meaningReversed: "恐懼改變、停滯、無法放手、內心抵抗。"
  },
  {
    id: 14,
    name: "節制",
    roman: "XIV",
    meaningUpright: "平衡、中庸、耐心、目的、意義。",
    meaningReversed: "失衡、過度、缺乏耐心、衝突、極端。"
  },
  {
    id: 15,
    name: "惡魔",
    roman: "XV",
    meaningUpright: "束縛、成癮、物質主義、性慾、陰影自我。",
    meaningReversed: "打破束縛、重獲自由、面對恐懼、釋放。"
  },
  {
    id: 16,
    name: "高塔",
    roman: "XVI",
    meaningUpright: "災難、劇變、啟示、突然的改變、混亂。",
    meaningReversed: "避免災難、恐懼改變、延遲的劇變、重建。"
  },
  {
    id: 17,
    name: "星星",
    roman: "XVII",
    meaningUpright: "希望、靈感、平靜、信心、更新。",
    meaningReversed: "絕望、缺乏信心、沮喪、不切實際的期望。"
  },
  {
    id: 18,
    name: "月亮",
    roman: "XVIII",
    meaningUpright: "幻覺、恐懼、焦慮、潛意識、直覺。",
    meaningReversed: "釋放恐懼、揭露真相、清晰、混亂平息。"
  },
  {
    id: 19,
    name: "太陽",
    roman: "XIX",
    meaningUpright: "快樂、溫暖、成功、活力、慶祝。",
    meaningReversed: "暫時的憂鬱、缺乏成功、虛榮、過度樂觀。"
  },
  {
    id: 20,
    name: "審判",
    roman: "XX",
    meaningUpright: "審判、重生、內在召喚、寬恕、覺醒。",
    meaningReversed: "自我懷疑、拒絕召喚、忽視教訓、缺乏反省。"
  },
  {
    id: 21,
    name: "世界",
    roman: "XXI",
    meaningUpright: "完成、整合、成就、旅行、圓滿。",
    meaningReversed: "未完成、缺乏封閉、延遲、空虛。"
  }
];

// --- ENGLISH MAJOR ARCANA ---
export const MAJOR_ARCANA_EN: CardData[] = [
  {
    id: 0,
    name: "The Fool",
    roman: "0",
    meaningUpright: "New beginnings, innocence, spontaneity, a free spirit.",
    meaningReversed: "Recklessness, risk-taking, bad decisions."
  },
  {
    id: 1,
    name: "The Magician",
    roman: "I",
    meaningUpright: "Manifestation, resourcefulness, power, inspired action.",
    meaningReversed: "Manipulation, poor planning, untapped talents."
  },
  {
    id: 2,
    name: "The High Priestess",
    roman: "II",
    meaningUpright: "Intuition, sacred knowledge, divine feminine, the subconscious mind.",
    meaningReversed: "Secrets, disconnected from intuition, withdrawal and silence."
  },
  {
    id: 3,
    name: "The Empress",
    roman: "III",
    meaningUpright: "Femininity, beauty, nature, nurturing, abundance.",
    meaningReversed: "Creative block, dependence on others."
  },
  {
    id: 4,
    name: "The Emperor",
    roman: "IV",
    meaningUpright: "Authority, establishment, structure, a father figure.",
    meaningReversed: "Domination, excessive control, lack of discipline, inflexibility."
  },
  {
    id: 5,
    name: "The Hierophant",
    roman: "V",
    meaningUpright: "Spiritual wisdom, religious beliefs, conformity, tradition, institutions.",
    meaningReversed: "Personal beliefs, freedom, challenging the status quo."
  },
  {
    id: 6,
    name: "The Lovers",
    roman: "VI",
    meaningUpright: "Love, harmony, relationships, values alignment, choices.",
    meaningReversed: "Self-love, disharmony, imbalance, misalignment of values."
  },
  {
    id: 7,
    name: "The Chariot",
    roman: "VII",
    meaningUpright: "Control, willpower, success, action, determination.",
    meaningReversed: "Self-discipline, opposition, lack of direction."
  },
  {
    id: 8,
    name: "Strength",
    roman: "VIII",
    meaningUpright: "Strength, courage, persuasion, influence, compassion.",
    meaningReversed: "Inner strength, self-doubt, low energy, raw emotion."
  },
  {
    id: 9,
    name: "The Hermit",
    roman: "IX",
    meaningUpright: "Soul-searching, introspection, being alone, inner guidance.",
    meaningReversed: "Isolation, loneliness, withdrawal."
  },
  {
    id: 10,
    name: "Wheel of Fortune",
    roman: "X",
    meaningUpright: "Good luck, karma, life cycles, destiny, a turning point.",
    meaningReversed: "Bad luck, resistance to change, breaking cycles."
  },
  {
    id: 11,
    name: "Justice",
    roman: "XI",
    meaningUpright: "Justice, fairness, truth, cause and effect, law.",
    meaningReversed: "Unfairness, lack of accountability, dishonesty."
  },
  {
    id: 12,
    name: "The Hanged Man",
    roman: "XII",
    meaningUpright: "Pause, surrender, letting go, new perspectives.",
    meaningReversed: "Delays, resistance, stalling, indecision."
  },
  {
    id: 13,
    name: "Death",
    roman: "XIII",
    meaningUpright: "Endings, change, transformation, transition.",
    meaningReversed: "Resistance to change, personal transformation, inner purging."
  },
  {
    id: 14,
    name: "Temperance",
    roman: "XIV",
    meaningUpright: "Balance, moderation, patience, purpose.",
    meaningReversed: "Imbalance, excess, self-healing, re-alignment."
  },
  {
    id: 15,
    name: "The Devil",
    roman: "XV",
    meaningUpright: "Shadow self, attachment, addiction, restriction, sexuality.",
    meaningReversed: "Releasing limiting beliefs, exploring dark thoughts, detachment."
  },
  {
    id: 16,
    name: "The Tower",
    roman: "XVI",
    meaningUpright: "Sudden change, upheaval, chaos, revelation, awakening.",
    meaningReversed: "Personal transformation, fear of change, averting disaster."
  },
  {
    id: 17,
    name: "The Star",
    roman: "XVII",
    meaningUpright: "Hope, faith, purpose, renewal, spirituality.",
    meaningReversed: "Lack of faith, despair, self-trust, disconnection."
  },
  {
    id: 18,
    name: "The Moon",
    roman: "XVIII",
    meaningUpright: "Illusion, fear, anxiety, subconscious, intuition.",
    meaningReversed: "Release of fear, repressed emotion, inner confusion."
  },
  {
    id: 19,
    name: "The Sun",
    roman: "XIX",
    meaningUpright: "Positivity, fun, warmth, success, vitality.",
    meaningReversed: "Inner child, feeling down, overly optimistic."
  },
  {
    id: 20,
    name: "Judgement",
    roman: "XX",
    meaningUpright: "Judgement, rebirth, inner calling, absolution.",
    meaningReversed: "Self-doubt, inner critic, ignoring the call."
  },
  {
    id: 21,
    name: "The World",
    roman: "XXI",
    meaningUpright: "Completion, integration, accomplishment, travel.",
    meaningReversed: "未完成、缺乏封閉、延遲、空虛。"
  }
];
